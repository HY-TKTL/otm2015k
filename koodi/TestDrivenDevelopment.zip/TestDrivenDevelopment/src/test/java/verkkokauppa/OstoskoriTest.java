package verkkokauppa;


import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class OstoskoriTest {
    
    @Before
    public void setUp() {
    }
    
    @Test
    public void dummy(){
        assertTrue(true);
    }
}
